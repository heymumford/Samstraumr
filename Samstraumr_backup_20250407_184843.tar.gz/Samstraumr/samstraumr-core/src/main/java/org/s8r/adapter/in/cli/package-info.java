/**
 * CLI adapter package for the inbound/primary side of the hexagonal architecture.
 * <p>
 * This package contains adapters that allow users to interact with the application
 * through a command-line interface. These adapters convert CLI commands into calls
 * to the application layer, and present application responses back to the user.
 * </p>
 * <p>
 * Key components in this package:
 * <ul>
 *   <li>ComponentCliAdapter - CLI adapter for component management</li>
 * </ul>
 * </p>
 * <p>
 * As part of the adapter layer in Clean Architecture, this package depends on the
 * application layer but not vice versa. It adapts external CLI requests to the
 * internal application services and ports.
 * </p>
 */
package org.s8r.adapter.in.cli;